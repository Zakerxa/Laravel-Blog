<!-- footer -->
<div class="bg-dark text-white p-5">
    <footer class="py-3">
        <ul class="nav justify-content-center">
            <li class="nav-item">
                <a href="#home" class="nav-link px-2">Home</a>
            </li>
            <li class="nav-item">
                <a href="#blogs" class="nav-link px-2">Blogs</a>
            </li>
            <li class="nav-item">
                <a href="#subscribe" class="nav-link px-2">Subscribe us</a>
            </li>
        </ul>
        <p class="text-center">&copy; 2021 Blogs By creativecoder, Inc</p>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous">
</script>
